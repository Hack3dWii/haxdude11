--Becks idiot
	-- Loads images from filepaths
	logo.image = love.graphics.newImage('potionlogo.png')
	background = love.graphics.newImage('bg.png')

	inspector = love.graphics.newImage('inspector.png')
	message = love.graphics.newImage('nogame.png')
	messagebg = love.graphics.newImage('bubble.png')
    -- love.draw() is called every frame. Any and all draw code goes here. (images, shapes, text etc.)
function love.draw()

	-- Start drawing to the top screen
	love.graphics.setScreen('top')

	-- Reset the current draw color to white
	love.graphics.setColor(255, 255, 255)

	-- Draw the background image
	love.graphics.draw(background, 0, 0)

	-- Cycle through all the bubbles in the bubble list, and draw them on their current screen
	-- aswell as drawing them at certain depths for 3D.
	for i, bubble in ipairs(bubbles) do
		love.graphics.setScreen(bubble.state)
		love.graphics.setDepth(bubble.size / 5)
		love.graphics.rectangle('fill', bubble.x, bubble.y, bubble.size, bubble.size)
	end

	-- Reset the screen to top after drawing bubbles on bottom, aswell as reset the depth.
	love.graphics.setScreen('top')
	love.graphics.setDepth(1)

	-- Draws the framerate
	love.graphics.setColor(255, 255, 255)
	love.graphics.rectangle('fill', 10, 15, font:getWidth('FPS: ' .. love.timer.getFPS()) + 10, font:getHeight() + 3)
	love.graphics.setColor(35, 31, 32)
	love.graphics.setFont(font)
	love.graphics.print('FPS: ' .. love.timer.getFPS(), 15, 15)

	love.graphics.setColor(255, 255, 255)

	-- Draw LövePotion logo
	love.graphics.rectangle('fill', logo.x - 3, logo.y - 3, 128 + 6, 128 + 6)
	love.graphics.draw(logo.image, logo.x, logo.y)

	-- Start drawing to the bottom screen
	love.graphics.setScreen('bottom')

	-- Draw the baby inspector with the no-game text
	love.graphics.draw(inspector, 0, 20)
	love.graphics.draw(messagebg, 160, 0)
	love.graphics.draw(message, 185, 10)